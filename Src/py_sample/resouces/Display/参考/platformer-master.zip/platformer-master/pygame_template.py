# initialize pygame and create window


# Game Loop
running = True
while running:
    # keep loop running at the right speed
    # Process input (events)

    # update

    # Draw / render

    pg.display.flip()

pg.quit()
